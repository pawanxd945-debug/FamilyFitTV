# FamilyFit TV — Fire TV Hackathon Starter

A React/Vite prototype for a TV-first family fitness experience.

## Included
- TV-oriented layout with large cards and visible keyboard focus
- Browse categories, search, workout details
- Sample video player with play/pause, mute, session timer, and finish action
- Save/favourite workouts
- Profile name and weekly goal settings
- Progress dashboard with completed workouts
- `localStorage` persistence
- Remote guide modal and Escape/Backspace handling
- Responsive browser layout

## Run on your computer
1. Extract the ZIP.
2. Open this folder in VS Code.
3. Open Terminal in this folder. Confirm `dir` shows `package.json`.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open the Local URL Vite prints, often `http://localhost:5173/`.

## Important: hackathon readiness
This is a **web prototype / starter project**, not a finished native Fire TV or Vega OS submission. The sample video links are public test clips and are not workout content; replace them with videos you have rights to use. Confirm the current official track requirements and accepted platform, then port/package and test the app on the required Fire TV device or simulator before submission.

## Suggested project pitch
**FamilyFit TV** helps households build a healthy movement habit through short, approachable routines for different moods and ability levels. It focuses on remote-first navigation, family-friendly discovery, simple progress tracking, and low-friction sessions on the largest screen in the home.

## Demo flow (under 3 minutes)
1. Open the home screen and navigate with a remote/keyboard.
2. Filter by Stretch or Family.
3. Open a workout and save it to My List.
4. Start the workout, demonstrate the player and session timer.
5. Finish the session and show the Progress page.
6. Open Profile & Settings and change the weekly goal.

## Before submission checklist
- [ ] Read current official hackathon rules and Fire TV track requirements.
- [ ] Package/port to the accepted Fire TV platform.
- [ ] Test navigation with a real remote and on the required simulator/device.
- [ ] Replace test videos with licensed workout clips and add captions/instructions.
- [ ] Test empty, error, slow-network, and app-resume states.
- [ ] Add project screenshots and a public demo video.
- [ ] Add a license and complete the Devpost submission fields.
