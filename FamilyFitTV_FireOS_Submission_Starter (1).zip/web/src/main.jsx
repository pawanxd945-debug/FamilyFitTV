import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Play, Search, Clock3, Flame, Users, HeartPulse, ChevronRight, X,
  CheckCircle2, Tv, Sparkles, Home, Bookmark, UserRound, ArrowLeft,
  Pause, Volume2, VolumeX, RotateCcw, CircleHelp, Settings, Trophy,
  CalendarDays, Dumbbell, Timer, Check, Menu
} from "lucide-react";
import "./styles.css";

/*
  FamilyFit TV — hackathon starter prototype.
  This is a web app that demonstrates a TV-first interaction model.
  Before hackathon submission, package/port it for the currently accepted
  Fire TV platform and test on the required simulator/device.
*/

const WORKOUTS = [
  { id: "w1", title: "Living Room Cardio", category: "Cardio", level: "All levels", mins: 12, kcal: 90, audience: "Family", color: "coral", emoji: "⚡", description: "A joyful, low-equipment routine to get the whole household moving.", tags: ["Energy", "Family"], video: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4", featured: true },
  { id: "w2", title: "Stretch & Reset", category: "Stretch", level: "Beginner", mins: 8, kcal: 35, audience: "Solo", color: "mint", emoji: "🌿", description: "Gentle full-body movement for a calm afternoon or evening.", tags: ["Calm", "Recovery"], video: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "w3", title: "Dance Party", category: "Dance", level: "All levels", mins: 15, kcal: 120, audience: "Family", color: "purple", emoji: "🎵", description: "Turn your living room into a dance floor with a feel-good session.", tags: ["Fun", "Music"], video: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" },
  { id: "w4", title: "Core Basics", category: "Strength", level: "Beginner", mins: 10, kcal: 70, audience: "Solo", color: "blue", emoji: "💪", description: "Simple strength movements with clear, beginner-friendly pacing.", tags: ["Strength", "Basics"], video: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "w5", title: "Kids Move Quest", category: "Family", level: "Easy", mins: 7, kcal: 45, audience: "Kids & family", color: "yellow", emoji: "🚀", description: "Playful movement prompts that make active time feel like a game.", tags: ["Kids", "Play"], video: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" },
  { id: "w6", title: "Morning Energy", category: "Cardio", level: "Intermediate", mins: 18, kcal: 145, audience: "Solo", color: "pink", emoji: "☀️", description: "A short energising session to help start the day moving.", tags: ["Morning", "Energy"], video: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "w7", title: "Desk Break", category: "Stretch", level: "Beginner", mins: 5, kcal: 20, audience: "Solo", color: "mint", emoji: "🧘", description: "A quick mobility break for shoulders, hips, and back.", tags: ["Quick", "Mobility"], video: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" },
  { id: "w8", title: "Family Challenge", category: "Family", level: "All levels", mins: 10, kcal: 65, audience: "Family", color: "yellow", emoji: "🏆", description: "Take turns choosing simple movement challenges together.", tags: ["Challenge", "Together"], video: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "w9", title: "Power Circuit", category: "Strength", level: "Intermediate", mins: 16, kcal: 130, audience: "Solo", color: "blue", emoji: "🔥", description: "A simple circuit format with rest between movement blocks.", tags: ["Power", "Circuit"], video: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" }
];
const CATEGORIES = ["For You", "Cardio", "Stretch", "Dance", "Strength", "Family"];
const STORAGE_KEY = "familyfit-tv-state-v1";

function readSavedState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : { completed: [], favorites: [], profile: "Pavan", goal: 3 };
  } catch {
    return { completed: [], favorites: [], profile: "Guest", goal: 3 };
  }
}

function App() {
  const initial = useMemo(() => readSavedState(), []);
  const [page, setPage] = useState("home");
  const [category, setCategory] = useState("For You");
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [playerWorkout, setPlayerWorkout] = useState(null);
  const [completed, setCompleted] = useState(initial.completed || []);
  const [favorites, setFavorites] = useState(initial.favorites || []);
  const [profile, setProfile] = useState(initial.profile || "Guest");
  const [goal, setGoal] = useState(initial.goal || 3);
  const [focusId, setFocusId] = useState("featured-start");
  const [showHelp, setShowHelp] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [muted, setMuted] = useState(false);
  const [playing, setPlaying] = useState(true);
  const [elapsed, setElapsed] = useState(0);
  const [videoError, setVideoError] = useState(false);
  const nodeRefs = useRef({});
  const playerRef = useRef(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ completed, favorites, profile, goal }));
  }, [completed, favorites, profile, goal]);

  const visibleWorkouts = useMemo(() => WORKOUTS.filter((w) => {
    const categoryMatch = category === "For You" || w.category === category;
    const queryMatch = `${w.title} ${w.category} ${w.description} ${w.tags.join(" ")}`.toLowerCase().includes(query.toLowerCase());
    const pageMatch = page !== "favorites" || favorites.includes(w.id);
    return categoryMatch && queryMatch && pageMatch;
  }), [category, query, page, favorites]);

  const setRef = (id) => (el) => { nodeRefs.current[id] = el; };
  const focusProps = (id) => ({
    ref: setRef(id),
    onFocus: () => setFocusId(id),
    className: focusId === id ? "tv-focus" : ""
  });

  function openDetails(workout) {
    setSelected(workout);
    setFocusId(`workout-${workout.id}`);
  }
  function startWorkout(workout) {
    setSelected(null);
    setPlayerWorkout(workout);
    setElapsed(0);
    setPlaying(true);
    setVideoError(false);
    setPage("player");
  }
  function exitPlayer() {
    setPlayerWorkout(null);
    setPage("home");
    setPlaying(false);
  }
  function finishWorkout() {
    if (playerWorkout && !completed.includes(playerWorkout.id)) setCompleted((old) => [...old, playerWorkout.id]);
    setPlayerWorkout(null);
    setPage("home");
    setPlaying(false);
  }
  function toggleFavorite(id) {
    setFavorites((old) => old.includes(id) ? old.filter((x) => x !== id) : [...old, id]);
  }
  function activateFocused() {
    const el = nodeRefs.current[focusId];
    if (el && typeof el.click === "function") el.click();
  }

  // TV remote / keyboard navigation. Native browser focus is kept as the source of truth.
  useEffect(() => {
    function onKeyDown(e) {
      const target = e.target;
      const typing = target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName);
      if (typing) {
        if (e.key === "Escape") { target.blur(); setSearchOpen(false); setQuery(""); }
        return;
      }
      if (e.key === "?" || (e.key === "h" && !e.ctrlKey && !e.metaKey)) {
        setShowHelp((v) => !v); return;
      }
      // TV D-pad navigation: move focus to the nearest visible focusable item in the requested direction.
      const directions = { ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right" };
      if (directions[e.key]) {
        const candidates = Array.from(document.querySelectorAll('button:not([disabled]), [tabindex="0"], input:not([disabled]), select:not([disabled])'))
          .filter((el) => el.getClientRects().length && getComputedStyle(el).visibility !== "hidden" && !el.closest('[aria-hidden="true"]'));
        const active = document.activeElement;
        if (!candidates.includes(active)) {
          e.preventDefault();
          (candidates[0] || document.body).focus?.();
          return;
        }
        const a = active.getBoundingClientRect();
        const ax = a.left + a.width / 2, ay = a.top + a.height / 2;
        let best = null, bestScore = Infinity;
        for (const el of candidates) {
          if (el === active) continue;
          const r = el.getBoundingClientRect();
          const x = r.left + r.width / 2, y = r.top + r.height / 2;
          const dx = x - ax, dy = y - ay;
          const primary = directions[e.key] === "left" ? -dx : directions[e.key] === "right" ? dx : directions[e.key] === "up" ? -dy : dy;
          const cross = directions[e.key] === "left" || directions[e.key] === "right" ? Math.abs(dy) : Math.abs(dx);
          if (primary <= 3) continue;
          const score = primary + cross * 1.8;
          if (score < bestScore) { bestScore = score; best = el; }
        }
        if (best) { e.preventDefault(); best.focus({ preventScroll: false }); }
        return;
      }
      if (e.key === "Escape" || e.key === "Backspace") {
        e.preventDefault();
        if (showHelp) { setShowHelp(false); return; }
        if (showSettings) { setShowSettings(false); return; }
        if (selected) { setSelected(null); return; }
        if (searchOpen) { setSearchOpen(false); setQuery(""); return; }
        if (page === "player") { exitPlayer(); return; }
        if (page !== "home") { setPage("home"); return; }
      }
      if (e.key === "Enter" && !selected && page !== "player") {
        // Native buttons/cards already respond to Enter; this fallback is for remote-only environments.
        if (document.activeElement === document.body) activateFocused();
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [focusId, selected, searchOpen, showHelp, showSettings, page, playerWorkout]);

  // Keep a session timer for the demo. The actual video is independently controlled by the player.
  useEffect(() => {
    if (page !== "player" || !playing) return;
    const timer = window.setInterval(() => setElapsed((n) => n + 1), 1000);
    return () => window.clearInterval(timer);
  }, [page, playing]);

  useEffect(() => {
    if (page === "player" && playerRef.current && playing) {
      const result = playerRef.current.play();
      if (result && typeof result.catch === "function") result.catch(() => setPlaying(false));
    }
  }, [page, playerWorkout, playing]);

  const formatTime = (sec) => `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;
  const completedWorkouts = WORKOUTS.filter(w => completed.includes(w.id));
  const savedWorkouts = WORKOUTS.filter(w => favorites.includes(w.id));
  const percentGoal = Math.min(100, Math.round((completed.length / Math.max(1, goal)) * 100));

  return (
    <div className="app">
      <header className="topbar">
        <button className="brand" {...focusProps("brand")} onClick={() => { setPage("home"); setCategory("For You"); }}>
          <span className="brand-icon"><HeartPulse size={22} /></span>
          <span>family<span className="brand-hot">fit</span><small> TV</small></span>
        </button>
        <nav className="main-nav" aria-label="Main navigation">
          <button {...focusProps("nav-home")} onClick={() => setPage("home")} className={page === "home" ? "nav-active" : ""}><Home size={16} /> Home</button>
          <button {...focusProps("nav-favorites")} onClick={() => setPage("favorites")} className={page === "favorites" ? "nav-active" : ""}><Bookmark size={16} /> My List</button>
          <button {...focusProps("nav-progress")} onClick={() => setPage("progress")} className={page === "progress" ? "nav-active" : ""}><Trophy size={16} /> Progress</button>
        </nav>
        <div className="top-actions">
          {searchOpen && <input className="search-input" aria-label="Search workouts" placeholder="Search workouts…" value={query} onChange={e => setQuery(e.target.value)} autoFocus />}
          <button aria-label="Search" {...focusProps("search")} className="round-icon" onClick={() => { setSearchOpen(v => !v); setQuery(""); }}><Search size={19} /></button>
          <button aria-label="Profile settings" {...focusProps("profile")} className="profile-button" onClick={() => setShowSettings(true)}><span>{profile.slice(0, 2).toUpperCase()}</span></button>
        </div>
      </header>

      {page === "player" && playerWorkout ? (
        <section className="player-page">
          <div className="player-top"><button className="back-button" onClick={exitPlayer}><ArrowLeft size={18} /> Back to workouts</button><span className="playing-label"><span className="green-dot" /> SESSION IN PROGRESS</span></div>
          <div className="player-layout">
            <div className={`video-frame ${playerWorkout.color}`}>
              {!videoError ? <video ref={playerRef} key={playerWorkout.id} src={playerWorkout.video} controls autoPlay muted={muted} onError={() => setVideoError(true)} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} /> : <div className="video-fallback"><span>{playerWorkout.emoji}</span><h3>Video preview unavailable</h3><p>You can still use the session timer and complete this demo workout.</p></div>}
              <div className="video-overlay-title"><span>{playerWorkout.category.toUpperCase()}</span><strong>{playerWorkout.title}</strong></div>
            </div>
            <aside className="player-info">
              <div className="eyebrow">YOUR SESSION</div><h1>{playerWorkout.title}</h1><p>{playerWorkout.description}</p>
              <div className="session-clock"><Timer size={20} /><div><span>Session timer</span><strong>{formatTime(elapsed)}</strong></div></div>
              <div className="player-controls">
                <button className="secondary-btn" onClick={() => { setPlaying(v => !v); if (playerRef.current) playing ? playerRef.current.pause() : playerRef.current.play().catch(() => {}); }}>{playing ? <Pause size={17} /> : <Play size={17} />} {playing ? "Pause" : "Resume"}</button>
                <button className="secondary-btn" onClick={() => setMuted(v => !v)}>{muted ? <VolumeX size={17} /> : <Volume2 size={17} />} {muted ? "Unmute" : "Mute"}</button>
              </div>
              <button className="primary-btn full-width" onClick={finishWorkout}><CheckCircle2 size={18} /> Finish session</button>
              <button className="text-button" onClick={exitPlayer}>Exit without completing</button>
              <p className="safety-note">Move at your own pace. Stop if you feel discomfort. Calorie figures are estimates, not measurements.</p>
            </aside>
          </div>
        </section>
      ) : page === "progress" ? (
        <main className="page-content">
          <div className="page-heading"><div className="eyebrow">YOUR MOVEMENT JOURNEY</div><h1>Progress that feels good.</h1><p>Celebrate every session. Small steps add up.</p></div>
          <div className="progress-grid">
            <div className="metric-card"><div className="metric-icon coral-bg"><Trophy /></div><span>Workouts completed</span><strong>{completed.length}</strong><small>of {WORKOUTS.length} available sessions</small></div>
            <div className="metric-card"><div className="metric-icon mint-bg"><Flame /></div><span>Estimated active minutes</span><strong>{completedWorkouts.reduce((sum,w)=>sum+w.mins,0)}</strong><small>Based on completed routines</small></div>
            <div className="metric-card"><div className="metric-icon purple-bg"><CalendarDays /></div><span>Weekly goal</span><strong>{completed.length}/{goal}</strong><div className="goal-track"><span style={{width:`${percentGoal}%`}} /></div><small>{percentGoal >= 100 ? "Goal reached — amazing!" : `${goal-completed.length > 0 ? goal-completed.length : 0} more to reach your goal`}</small></div>
          </div>
          <section className="subsection"><div className="section-title"><h2>Completed sessions</h2><span>{completedWorkouts.length} total</span></div>
            {completedWorkouts.length ? <div className="workout-grid">{completedWorkouts.map(w => <WorkoutCard key={w.id} w={w} completed={completed} favorites={favorites} focusProps={focusProps} onOpen={openDetails} onFavorite={toggleFavorite} />)}</div> : <div className="empty-panel"><Trophy size={32}/><h3>Your first win is waiting</h3><p>Finish any workout and it will show up here.</p><button className="primary-btn" onClick={() => setPage("home")}>Explore workouts</button></div>}
          </section>
        </main>
      ) : (
        <main>
          {page === "home" && <section className="hero">
            <div className="hero-copy">
              <div className="eyebrow"><Sparkles size={14} /> YOUR LIVING ROOM, YOUR PLAYGROUND</div>
              <h1>Feel good.<br/><span>Move together.</span></h1>
              <p>Short, joyful workouts made for the biggest screen in your home. Choose a routine, grab your remote, and get moving.</p>
              <div className="hero-actions"><button className="primary-btn" {...focusProps("featured-start")} onClick={() => openDetails(WORKOUTS[0])}><Play size={18} fill="currentColor"/> Start a 12-min workout</button><span className="hero-note"><span className="green-dot"/> No equipment needed</span></div>
              <div className="hero-stats"><div><strong>{completed.length}</strong><span>sessions completed</span></div><i/><div><strong>5–18 <small>min</small></strong><span>short daily routines</span></div><i/><div><strong>All</strong><span>fitness levels welcome</span></div></div>
            </div>
            <div className="hero-art" aria-label="Abstract illustration of people exercising"><div className="sun-disc"/><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="art-floor"/><div className="illustration-person person-a"><i className="head"/><i className="torso"/><i className="arm arm-a"/><i className="arm arm-b"/><i className="leg leg-a"/><i className="leg leg-b"/></div><div className="illustration-person person-b"><i className="head"/><i className="torso"/><i className="arm arm-a"/><i className="arm arm-b"/><i className="leg leg-a"/><i className="leg leg-b"/></div><div className="float-note note-top"><Flame size={16}/> Small steps count</div><div className="float-note note-bottom"><Users size={16}/> Better together</div></div>
          </section>}

          {page === "favorites" && <div className="page-heading compact-heading"><div className="eyebrow">YOUR PERSONAL COLLECTION</div><h1>My List</h1><p>Keep your favourite routines close at hand.</p></div>}

          <section className="workout-section">
            <div className="section-heading"><div><div className="section-kicker">{page === "favorites" ? "SAVED FOR LATER" : "MADE FOR YOUR MOOD"}</div><h2>{page === "favorites" ? "Your saved workouts" : "Find your flow"}</h2></div><button {...focusProps("reset-category")} className="view-all" onClick={() => {setCategory("For You");setQuery("");}}>Reset filters <ChevronRight size={16}/></button></div>
            {page === "home" && <div className="category-row">{CATEGORIES.map((cat,i)=><button key={cat} {...focusProps("category-"+cat)} className={`category-pill ${category===cat?"selected":""}`} onClick={()=>setCategory(cat)}><span>{["✦","⚡","🌿","♫","💪","👨‍👩‍👧"][i]}</span>{cat}</button>)}</div>}
            <div className="workout-grid">
              {visibleWorkouts.map(w => <WorkoutCard key={w.id} w={w} completed={completed} favorites={favorites} focusProps={focusProps} onOpen={openDetails} onFavorite={toggleFavorite}/>)}
            </div>
            {visibleWorkouts.length===0 && <div className="empty-panel"><Search size={30}/><h3>{page==="favorites"?"No saved workouts yet":"No workouts found"}</h3><p>{page==="favorites"?"Save a routine with the bookmark button to see it here.":"Try another search or category."}</p><button className="secondary-btn" onClick={()=>{setPage("home");setCategory("For You");setQuery("");}}>Browse all workouts</button></div>}
          </section>
          <section className="tv-tip"><div className="tv-tip-icon"><Tv size={24}/></div><div><strong>Made for the big screen</strong><p>Use your remote's arrow keys to move between controls and press OK/Enter to select.</p></div><button className="help-shortcut" onClick={()=>setShowHelp(true)}><CircleHelp size={18}/> Remote guide</button></section>
        </main>
      )}

      <footer><div className="footer-brand"><span className="brand-icon small"><HeartPulse size={15}/></span> family<span className="brand-hot">fit</span> TV</div><span>Move at your own pace · Built for family time</span><span className="demo-label">HACKATHON PROTOTYPE</span></footer>

      {selected && <div className="modal-backdrop" onClick={()=>setSelected(null)}><section className="detail-modal" role="dialog" aria-modal="true" aria-label={selected.title} onClick={e=>e.stopPropagation()}>
        <button className="close-btn" aria-label="Close" onClick={()=>setSelected(null)}><X size={20}/></button>
        <div className={`modal-art ${selected.color}`}><span>{selected.emoji}</span><div className="modal-art-orbit"/></div>
        <div className="modal-copy"><div className="eyebrow">{selected.category} · {selected.level}</div><h2>{selected.title}</h2><p>{selected.description}</p><div className="detail-facts"><span><Clock3 size={17}/>{selected.mins} minutes</span><span><Flame size={17}/>{selected.kcal} kcal est.</span><span><Users size={17}/>{selected.audience}</span></div>
          <div className="modal-actions"><button className="primary-btn" onClick={()=>startWorkout(selected)}><Play size={18} fill="currentColor"/> Play workout</button><button className={`secondary-btn ${favorites.includes(selected.id)?"saved":""}`} onClick={()=>toggleFavorite(selected.id)}>{favorites.includes(selected.id)?<Check size={17}/>:<Bookmark size={17}/>} {favorites.includes(selected.id)?"Saved":"Save to My List"}</button></div>
          <p className="safety-note">This prototype uses sample preview clips. Replace them with licensed, relevant workout videos before publishing.</p>
        </div>
      </section></div>}

      {showSettings && <div className="modal-backdrop" onClick={()=>setShowSettings(false)}><section className="settings-modal" role="dialog" aria-modal="true" onClick={e=>e.stopPropagation()}><button className="close-btn" onClick={()=>setShowSettings(false)}><X size={20}/></button><div className="eyebrow">PERSONALISE YOUR SPACE</div><h2>Profile & settings</h2><label className="field-label">Display name<input value={profile} maxLength={24} onChange={e=>setProfile(e.target.value)} placeholder="Your name"/></label><label className="field-label">Weekly workout goal<select value={goal} onChange={e=>setGoal(Number(e.target.value))}><option value={2}>2 sessions</option><option value={3}>3 sessions</option><option value={4}>4 sessions</option><option value={5}>5 sessions</option><option value={7}>7 sessions</option></select></label><p className="settings-note">Your progress and saved workouts are stored in this browser using localStorage.</p><button className="primary-btn full-width" onClick={()=>setShowSettings(false)}>Save settings</button></section></div>}

      {showHelp && <div className="modal-backdrop" onClick={()=>setShowHelp(false)}><section className="help-modal" role="dialog" aria-modal="true" onClick={e=>e.stopPropagation()}><button className="close-btn" onClick={()=>setShowHelp(false)}><X size={20}/></button><div className="eyebrow">QUICK GUIDE</div><h2>Use your TV remote</h2><div className="key-guide"><div><span>↑ ↓ ← →</span><p>Move between buttons and workout cards</p></div><div><span>OK / Enter</span><p>Select a workout or activate a control</p></div><div><span>Back / Esc</span><p>Close a dialog or return to the home screen</p></div><div><span>?</span><p>Open this remote guide</p></div></div><button className="primary-btn full-width" onClick={()=>setShowHelp(false)}>Got it</button></section></div>}
    </div>
  );
}

function WorkoutCard({w, completed, favorites, focusProps, onOpen, onFavorite}) {
  const isDone = completed.includes(w.id);
  const isSaved = favorites.includes(w.id);
  return <article className="workout-card" tabIndex={0} {...focusProps("workout-"+w.id)} onClick={()=>onOpen(w)} onKeyDown={e=>{if(e.key==="Enter")onOpen(w);}}>
    <div className={`card-art ${w.color}`}><div className="card-glow"/><span className="workout-emoji">{w.emoji}</span><span className="card-duration"><Clock3 size={13}/>{w.mins} MIN</span>{isDone&&<span className="done-tag"><CheckCircle2 size={13}/> Done</span>}<button className={`favorite-btn ${isSaved?"is-saved":""}`} aria-label={isSaved?"Remove from My List":"Save to My List"} onClick={e=>{e.stopPropagation();onFavorite(w.id);}}>{isSaved?<Check size={15}/>:<Bookmark size={15}/>}</button></div>
    <div className="card-body"><div className="card-meta"><span>{w.category.toUpperCase()}</span><span>•</span><span>{w.level}</span></div><h3>{w.title}</h3><p>{w.description}</p><div className="card-footer"><span><Flame size={14}/>{w.kcal} kcal est.</span><button className="round-play" aria-label={`Open ${w.title}`} onClick={e=>{e.stopPropagation();onOpen(w);}}><Play size={14} fill="currentColor"/></button></div></div>
  </article>;
}

createRoot(document.getElementById("root")).render(<App />);
