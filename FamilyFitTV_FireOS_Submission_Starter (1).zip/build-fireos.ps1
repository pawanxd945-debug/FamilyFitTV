$ErrorActionPreference = "Stop"
Push-Location "$PSScriptRoot/web"
npm install
npm run build
Pop-Location
$assets = "$PSScriptRoot/android/app/src/main/assets/www"
if (Test-Path $assets) { Remove-Item $assets -Recurse -Force }
New-Item -ItemType Directory -Path $assets -Force | Out-Null
Copy-Item "$PSScriptRoot/web/dist/*" $assets -Recurse -Force
Write-Host "Web assets copied into Android app. Next: open the android folder in Android Studio and build an APK." -ForegroundColor Green
